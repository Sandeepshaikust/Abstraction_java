package Javahandsone;

public interface NationalBank {
	
 void calculateFd();
 
	 
 }

