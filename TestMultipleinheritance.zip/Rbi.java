package Javahandsone;

public class Rbi
{
 static final int dollerRate = 80;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          doller=72;

  public int readDollerRate() 
  {
	return dollerRate;
   }
 
}
