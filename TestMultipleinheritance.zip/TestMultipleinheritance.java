package Javahandsone;

public class TestMultipleinheritance{
	public static void main(String[] args) {
		
		Sbi sbihyd =new Sbi();
		sbihyd.calculateFd();
		// TODO Auto-generated method stub
		int dr=sbihyd.readDollerRate();
		System.out.println(dr);

	}

	
	}


