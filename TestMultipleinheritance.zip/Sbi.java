package Javahandsone;

public class Sbi extends Rbi implements NationalBank{
	
	public void calculateFd() {
		System.out.println("FD rate od intrest is 8%");
	}

}
