package Javahandsone;

public class circle extends shape {
	


	@Override
	public void calculatearea() {
		// TODO Auto-generated method stub
		System.out.println("Area of circle");

	}

	
	
}
