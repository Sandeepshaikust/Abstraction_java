package Javahandsone;

public class rectangle extends shape{
	
	void caluculatearea() {
		System.out.println("Area of rectangle");

}
}