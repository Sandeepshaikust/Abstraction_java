package Javahandsone;

public abstract class shape {
	
abstract void calculatearea();

}
