package FileHandling;

import java.io.FileWriter;
import java.io.IOException;

public class creatFile {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		FileWriter myWriter=new FileWriter("C://test//UST_Java1.txt");
		myWriter.write("Hello"+"\n\r");
		myWriter.append("Adding a new line");
		myWriter.flush();
		
		

	}

}
