package FileHandling;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class readFile {
	
	static File myFile;
		
	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		try {
		myFile= new File("C:\\test\\UST_Java.txt");
		
           System.out.println(myFile.exists());
           
		Scanner myScanner=new Scanner(myFile);
		
		while(myScanner.hasNextLine()) {
			
		String line =myScanner.nextLine();
		
		System.out.println(line);
		
		
		}
	}
	catch(FileNotFoundException f) {
		System.out.println("File not found");}
	finally {
		myFile=null;
		
	}
	}
}

	
	

	
		
