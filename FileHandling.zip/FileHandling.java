package FileHandling;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileHandling {
	static File myFile;
	static String [] userdetails;
	public static void main(String[] args) throws FileNotFoundException {
try {
	
		// TODO Auto-generated method stub
		myFile= new File("C://test//File1.txt");
		 System.out.println(myFile.exists());
		 Scanner myScanner=new Scanner(myFile);
		 while(myScanner.hasNextLine()) {
				
				String line =myScanner.nextLine();
				
				System.out.println(line);
				userdetails = line.split(",");
				for(int i=0;i<userdetails.length;i++) {
					switch(i) {
					case 0:
						System.out.println("username:" + userdetails[i]);
						break;
					}
				case 1:
					System.out.println("password:" +userdetails[i]);
					break;
				}
						
				
					}

			
	}
		 }catch(FileNotFoundException f) {
System.out.println("File not found");
	}
		finally {
		myFile=null;
	}
	}

}
